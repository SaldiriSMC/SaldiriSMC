const { DataTypes } = require('sequelize');
const { sequelize } = require('../../../config/mySqlConnection')

const chairs = sequelize.define('chairs', {tenantId:{
    type:DataTypes.INTEGER,
    references:{
      model:"tenants",
      key:"id"
    },
  },Model:{
          type:DataTypes.STRING
        },},
);

module.exports = chairs;
