const httpStatus = require('http-status');
const Model = require("../models/chairs.model.js")
const ApiError = require('../../../utils/ApiError.js');

const create = async (userBody,tenantId) => {
  return Model.create(userBody);
};

const getById= async (id) => {
  const chairs = await Model.findOne({where:{ id:id }});
  return chairs
};

const updateById = async (updateBody,id) => {
  const chairs = await getById(id);
  if (!chairs) {
    throw new ApiError(httpStatus.NOT_FOUND, 'chairs not found');
  }else{
    const chairs = await Model.update(updateBody,{where:{id:id}})
    return chairs 
  }
};

const deleteById = async (id) => {
  const chairs  = await Model.findByPk(id);
  if (!chairs ) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  await chairs.destroy();
};

module.exports = {
  create,
  getById,
  updateById,
  deleteById,
};
