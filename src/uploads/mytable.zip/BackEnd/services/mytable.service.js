const httpStatus = require('http-status');
const Model = require("../models/mytable.model.js")
const ApiError = require('../../../utils/ApiError.js');

const create = async (userBody,tenantId) => {
  return Model.create(userBody);
};

const getById= async (id) => {
  const mytable = await Model.findOne({where:{ id:id }});
  return mytable
};

const updateById = async (updateBody,id) => {
  const mytable = await getById(id);
  if (!mytable) {
    throw new ApiError(httpStatus.NOT_FOUND, 'mytable not found');
  }else{
    const mytable = await Model.update(updateBody,{where:{id:id}})
    return mytable 
  }
};

const deleteById = async (id) => {
  const mytable  = await Model.findByPk(id);
  if (!mytable ) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  await mytable.destroy();
};

module.exports = {
  create,
  getById,
  updateById,
  deleteById,
};
