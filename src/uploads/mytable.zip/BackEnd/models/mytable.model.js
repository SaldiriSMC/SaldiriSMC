const { DataTypes } = require('sequelize');
const { sequelize } = require('../../../config/mySqlConnection')

const mytable = sequelize.define('mytable', {tenantId:{
    type:DataTypes.INTEGER,
    references:{
      model:"tenants",
      key:"id"
    },
  },Model:{
          type:DataTypes.STRING
        },},
);

module.exports = mytable;
