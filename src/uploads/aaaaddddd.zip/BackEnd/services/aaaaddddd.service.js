const httpStatus = require('http-status');
const Model = require("../models/aaaaddddd.model.js")
const ApiError = require('../../../utils/ApiError.js');

const create = async (userBody,tenantId) => {
  return Model.create(userBody);
};

const getById= async (id) => {
  const aaaaddddd = await Model.findOne({where:{ id:id }});
  return aaaaddddd
};

const updateById = async (updateBody,id) => {
  const aaaaddddd = await getById(id);
  if (!aaaaddddd) {
    throw new ApiError(httpStatus.NOT_FOUND, 'aaaaddddd not found');
  }else{
    const aaaaddddd = await Model.update(updateBody,{where:{id:id}})
    return aaaaddddd 
  }
};

const deleteById = async (id) => {
  const aaaaddddd  = await Model.findByPk(id);
  if (!aaaaddddd ) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  await aaaaddddd.destroy();
};

module.exports = {
  create,
  getById,
  updateById,
  deleteById,
};
