const { DataTypes } = require('sequelize');
const { sequelize } = require('../../../config/mySqlConnection')

const aaaaddddd = sequelize.define('aaaaddddd', {tenantId:{
    type:DataTypes.INTEGER,
    references:{
      model:"tenants",
      key:"id"
    },
  },aaa:{
          type:undefined
        },},
);

module.exports = aaaaddddd;
