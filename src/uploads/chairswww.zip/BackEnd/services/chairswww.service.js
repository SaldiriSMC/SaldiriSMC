const httpStatus = require('http-status');
const Model = require("../models/chairswww.model.js")
const ApiError = require('../../../utils/ApiError.js');

const create = async (userBody,tenantId) => {
  return Model.create(userBody);
};

const getById= async (id) => {
  const chairswww = await Model.findOne({where:{ id:id }});
  return chairswww
};

const updateById = async (updateBody,id) => {
  const chairswww = await getById(id);
  if (!chairswww) {
    throw new ApiError(httpStatus.NOT_FOUND, 'chairswww not found');
  }else{
    const chairswww = await Model.update(updateBody,{where:{id:id}})
    return chairswww 
  }
};

const deleteById = async (id) => {
  const chairswww  = await Model.findByPk(id);
  if (!chairswww ) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  await chairswww.destroy();
};

module.exports = {
  create,
  getById,
  updateById,
  deleteById,
};
