const { DataTypes } = require('sequelize');
const { sequelize } = require('../../../config/mySqlConnection')

const chairswww = sequelize.define('chairswww', {tenantId:{
    type:DataTypes.INTEGER,
    references:{
      model:"tenants",
      key:"id"
    },
  },Model:{
          type:DataTypes.STRING
        },},
);

module.exports = chairswww;
