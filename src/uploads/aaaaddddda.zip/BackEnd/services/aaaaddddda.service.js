const httpStatus = require('http-status');
const Model = require("../models/aaaaddddda.model.js")
const ApiError = require('../../../utils/ApiError.js');

const create = async (userBody,tenantId) => {
  return Model.create(userBody);
};

const getById= async (id) => {
  const aaaaddddda = await Model.findOne({where:{ id:id }});
  return aaaaddddda
};

const updateById = async (updateBody,id) => {
  const aaaaddddda = await getById(id);
  if (!aaaaddddda) {
    throw new ApiError(httpStatus.NOT_FOUND, 'aaaaddddda not found');
  }else{
    const aaaaddddda = await Model.update(updateBody,{where:{id:id}})
    return aaaaddddda 
  }
};

const deleteById = async (id) => {
  const aaaaddddda  = await Model.findByPk(id);
  if (!aaaaddddda ) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  await aaaaddddda.destroy();
};

module.exports = {
  create,
  getById,
  updateById,
  deleteById,
};
