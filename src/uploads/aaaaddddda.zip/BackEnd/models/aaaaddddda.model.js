const { DataTypes } = require('sequelize');
const { sequelize } = require('../../../config/mySqlConnection')

const aaaaddddda = sequelize.define('aaaaddddda', {tenantId:{
    type:DataTypes.INTEGER,
    references:{
      model:"tenants",
      key:"id"
    },
  },aaa:{
          type:undefined
        },},
);

module.exports = aaaaddddda;
