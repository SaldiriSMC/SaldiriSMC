const { DataTypes } = require('sequelize');
const { sequelize } = require('../../../config/mySqlConnection')

const carListaaaa = sequelize.define('carListaaaa', {tenantId:{
    type:DataTypes.INTEGER,
    references:{
      model:"tenants",
      key:"id"
    },
  },name:{
          type:DataTypes.STRING
        },},
);

module.exports = carListaaaa;
