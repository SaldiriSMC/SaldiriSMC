const httpStatus = require('http-status');
const Model = require("../models/carListaaaa.model.js")
const ApiError = require('../../../utils/ApiError.js');

const create = async (userBody,tenantId) => {
  return Model.create(userBody);
};

const getById= async (id) => {
  const carListaaaa = await Model.findOne({where:{ id:id }});
  return carListaaaa
};

const updateById = async (updateBody,id) => {
  const carListaaaa = await getById(id);
  if (!carListaaaa) {
    throw new ApiError(httpStatus.NOT_FOUND, 'carListaaaa not found');
  }else{
    const carListaaaa = await Model.update(updateBody,{where:{id:id}})
    return carListaaaa 
  }
};

const deleteById = async (id) => {
  const carListaaaa  = await Model.findByPk(id);
  if (!carListaaaa ) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  await carListaaaa.destroy();
};

module.exports = {
  create,
  getById,
  updateById,
  deleteById,
};
