const httpStatus = require('http-status');
const Model = require("../models/aaaa.model.js")
const ApiError = require('../../../utils/ApiError.js');

const create = async (userBody,tenantId) => {
  return Model.create(userBody);
};

const getById= async (id) => {
  const aaaa = await Model.findOne({where:{ id:id }});
  return aaaa
};

const updateById = async (updateBody,id) => {
  const aaaa = await getById(id);
  if (!aaaa) {
    throw new ApiError(httpStatus.NOT_FOUND, 'aaaa not found');
  }else{
    const aaaa = await Model.update(updateBody,{where:{id:id}})
    return aaaa 
  }
};

const deleteById = async (id) => {
  const aaaa  = await Model.findByPk(id);
  if (!aaaa ) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  await aaaa.destroy();
};

module.exports = {
  create,
  getById,
  updateById,
  deleteById,
};
