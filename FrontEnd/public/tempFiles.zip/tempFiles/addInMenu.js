// go to pages/sideMenu.js file and add this code into sideListTenet ary

{name:'#tableTitle',id:1,path:'/#tableName',icon:<MailIcon/>},