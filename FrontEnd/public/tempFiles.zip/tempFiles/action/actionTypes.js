export const CREATE_#tableTitle = "CREATE_#tableTitle";
export const CREATE_#tableTitle_SUCCESS = "CREATE_#tableTitle_SUCCESS";
export const CREATE_#tableTitle_FAILURE = "CREATE_#tableTitleLOGIN_FAILURE";

export const GET_#tableTitle = "GET_#tableTitle";
export const GET_#tableTitle_SUCCESS = "GET_#tableTitle_SUCCESS";
export const GET_#tableTitle_FAILURE = "GET_#tableTitle_FAILURE";

export const UPDATE_#tableTitle = "UPDATE_#tableTitle";
export const UPDATE_#tableTitle_SUCCESS = "UPDATE_#tableTitle_SUCCESS";
export const UPDATE_#tableTitle_FAILURE = "UPDATE_#tableTitle_FAILURE";


export const DELETE_#tableTitle = "DELETE_#tableTitle";
export const DELETE_#tableTitle_SUCCESS = "DELETE_#tableTitle_SUCCESS";
export const DELETE_#tableTitle_FAILURE = "DELETE_#tableTitle_FAILURE";