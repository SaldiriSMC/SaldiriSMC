// paste this line top of page 
import #tableName from "./#tableNameSaga";

// add this function in to  yield all arr 

#tableName()

