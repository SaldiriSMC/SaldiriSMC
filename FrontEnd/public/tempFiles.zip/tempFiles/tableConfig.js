import { constants } from "buffer"

// place this code into constants/tableConfig file 
#tableName