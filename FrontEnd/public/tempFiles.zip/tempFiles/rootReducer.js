// paste this line top of the code 
import #tableNameReducer from "./#tableNameReducer";


// add this line into combineReducers function
#tableName: #tableNameReducer,
