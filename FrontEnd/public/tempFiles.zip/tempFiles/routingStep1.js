// go to app.js file paste this code top of page 
import #tableTitle from './pages/#tableName';
// go to app.js file paste this code in to Routs  

<Route exact path='/#tableName' element={<PrivateRoute loader={loader} setLoader={setLoader} />}>
<Route exact path='/#tableName' element={< #tableTitle  loader={loader} setLoader={setLoader} />}/>
</Route>
