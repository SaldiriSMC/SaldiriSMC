
// add this line in all URLs
#tableName:'/#tableName',